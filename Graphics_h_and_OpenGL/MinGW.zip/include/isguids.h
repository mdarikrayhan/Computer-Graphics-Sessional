#ifndef _ISGUID_H
#define _ISGUID_H
#if __GNUC__ >=3
#pragma GCC system_header
#endif

#ifdef __cplusplus
extern "C" {
#endif
extern const GUID CLSID_InternetShortcut;
extern const GUID IID_IUniformResourceLocator;
#ifdef __cplusplus
}
#endif
#endif
